# Online Resource 2 - supporting numerical records

Article title: Comparative study of federated adaptation strategies for remote-sensing change detection
Journal: Journal of Applied Remote Sensing
Authors (in article order): Tian Jiang; Hao Wang; Yu Shi; Yuxiang Li; Xintao Fu.
Corresponding author: Hao Wang.
Corresponding-author affiliation: Information Science and Technology College, Dalian Maritime University, 1 Linghai Road, Ganjingzi District, Dalian, 116026, Liaoning, China.
Corresponding-author email: wh_2220233828@dlmu.edu.cn.
Resource version: v003, prepared 28 November 2026 for GitHub hosting.

This resource accompanies "Comparative study of federated adaptation strategies for remote-sensing change detection" and Online Resource 1. It contains retained
numerical records and existing derived analyses. It includes no raw imagery,
model weights, private implementation, image-level predictions, or complete
training histories. The supporting PDF (Online Resource 1) and this numerical archive (Online Resource 2) are hosted in the accompanying GitHub repository: https://github.com/TianJiang204/Comparative-study-of-federated-adaptation-strategies-for-remote-sensing-change-detection/tree/main/supplementary. These resources are hosted by the authors; this does not imply publication as journal-hosted attachments.

| File | Scope |
|---|---|
| `MAIN_R50_RESULTS.csv` | All 120 federated configuration–dataset–seed endpoints, in percent; observed maxima are diagnostic only |
| `derived_R50_prediction_diagnostics.csv` | All 120 R50 prediction-summary rows, including all 12 exact all-background outcomes |
| `derived_retained_common_round_metrics.csv` | All 600 retained-history common points, R10/R20/R30/R40/R50 |
| `IJML_logical_communication_cell_audit_v002_20260921.csv` | 120 communication cells using actual participation |
| `IJML_parameter_communication_summary_v002_20260921.csv` | Eight trainable/synchronized/aggregated state summaries |
| `centralized_reference_r50_results_20260923.csv` | 15 centralized **E50** cells; historical `r50_test_mIoU` means epoch 50 in this file |
| `derived_training_dataset_audit.csv` | Five pooled training-source summaries |
| `derived_training_partition_audit.csv` | 15 unique partition summaries |
| `derived_training_client_audit.csv` | 150 configured-client rows, including empty clients |
| `derived_update_step_budget.csv` | 15 reconstructed FL/centralized update-count comparisons |
| `derived_seed_summary_sensitivity.csv` | Descriptive mean/median/minimum rank sensitivity |
| `derived_family_rank_sensitivity.csv` | Descriptive LEVIR-family weighting/exclusion sensitivity |
| `derived_lodo_ranks.csv` | Descriptive leave-one-dataset-out ranks |
| `derived_dataset_performance_communication_v014.csv` | 40 joined dataset/configuration summaries: R50 mean/sample SD, each seed's K and bytes, mean/min/max traffic; computed solely from the existing cell records |
| `source_identity.json` | Retained per-cell source/configuration/plan identities and explicit missing-provenance boundaries |
| `export_index.json` | Source hashes, selected columns, removed operational/path columns, row counts and E50 field semantics |

Join tables on configuration, dataset, and seed, using the dataset/method aliases
specified by their identifier columns. `WHUCD` and `WHU-CD` refer to the same task.
R50 means use three seeds and sample SD (`ddof=1`). Foreground prediction ratios
are fractions unless explicitly named percent. Source-mask composition is before
augmentation and is not a test-label target. `k_total` is the sum of participating
clients across 50 rounds; bytes equal `2 * k_total * communicated_state_bytes`.
Decimal MB/GB are 10^6/10^9 bytes. Server-local optimizer moments are excluded.

The 16 CSV/JSON data files are unchanged from the inherited v019 numerical
resource; this README identifies the current article and supplementary-material scope. Historical
version suffixes in data filenames identify their origin, not a different
evaluation endpoint. In particular, the `v014` joined CSV remains the retained
40-row analysis and has not been regenerated.

Operational
status, internal history paths, evidence prose and timestamps were removed from
selected CSVs. The earlier resource's PASS or provenance-verdict fields are not
carried over as certifications. Source-mask audit summaries and
calibration statements remain historical records, not newly remeasured data.

The 16 CSV/JSON files are retained byte-for-byte in this supplementary package.
The accompanying local manuscript preparation records their SHA-256 hashes.
Historical suffixes in filenames are retained for traceability. This package
contains numerical records, not executable audit scripts or a complete training
reproduction environment.

For an independent numerical cross-check, group `MAIN_R50_RESULTS.csv` by method
and dataset, retain all three seeds, and compute the arithmetic mean and sample
SD (`ddof=1`), then compare the 40 groups with Main Table 3 at its displayed
precision. Logical traffic can be checked using the formula above and each
cell's actual participation and synchronized-state size. Main Table 4(a)
averages the 15 dataset–seed partitions equally; Table 4(b) averages the three
seeds of each dataset equally. These are explicit check methods, not a claim
that every current verification script performs those calculations.

No result-regeneration command is required for online inspection. Read the
limitations in Online Resource 1: file or numerical agreement does not certify
the complete historical snapshot, text-sidecar provenance, calibration history
or independent retraining reproducibility. Raw histories and the full training
implementation are not distributed in this supplementary package.
